str_list = ["Emma", "Jon", "", "Kelly", None, "Eric", ""]
ln = len(str_list)
print(str_list)
count = 0
for i in range(0, ln):
    if str_list[i]=="":
        count += 1
for i in range(0, count):
    str_list.remove("")
print(str_list)