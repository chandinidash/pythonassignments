str = "P@#yt26ho^&n5ve"
ln = len(str)
print(str)
ndigits = nchars = nsymbols = 0
for i in range(0, ln):
    if str[i].isdigit():
        ndigits += 1
    elif str[i].isalpha():
        nchars += 1
    else:
        nsymbols += 1
print("Chars = ", nchars)
print("Digits = ", ndigits)
print("Symbol = ", nsymbols)
