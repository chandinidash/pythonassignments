str1 = "PyThOnIndIA"
lenOfStr = len(str1)
print(str1)
str2=""
str3=""
for i in range(0,lenOfStr):
    if str1[i].islower():
        str2 = str2+str1[i]
    else:
        str3 = str3+str1[i]
str2 = str2 + str3
print(str2)
