my_list = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110]
print("Given list:",my_list)
ln = len(my_list)
for i in range(1,ln,2):
    print(my_list[i])