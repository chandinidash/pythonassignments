num = int(input("Enter number: "))
count=0
while True:
    if num < 10:
        count += 1
        break
    else:
        count +=1
        num /=10
print("Number of digits:",count)
