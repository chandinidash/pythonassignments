list_x = [55, 96, 100, 160, 105, 505, 100, 200]
ln = len(list_x)
for i in range(0,ln):
    if list_x[i]>500:
        break
    elif list_x[i]>150:
        continue
    elif list_x[i]%5==0:
        print(list_x[i])
