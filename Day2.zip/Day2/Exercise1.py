numbers_x = [10, 20, 30, 40, 10]
numbers_y = [75, 65, 35, 75, 30]
len_x = len(numbers_x)
print("Given list:",numbers_x)
if numbers_x[0] == numbers_x[len_x-1]:
    print("result is True")
else:
    print("result is False")

len_y = len(numbers_y)
print("Given list:",numbers_y)
if numbers_y[0] == numbers_y[len_y-1]:
    print("result is True")
else:
    print("result is False")