numbers_x = [10, 20, 33, 46, 55]
len_x = len(numbers_x)
print("Given list:",numbers_x)
for i in range(0,len_x):
    if numbers_x[i]%5==0:
        print(numbers_x[i])