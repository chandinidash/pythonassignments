str_x = "Emma is good developer. Emma is a writer"
ln = len(str_x)
str = "Emma"
i = 0
count = 0
while True:
    i = str_x.find(str,i,ln-1)
    if i < 0:
        break
    else:
        count += 1
        i += 1
print("Given String: ",str_x)
print(str,"appeared",count,"times")