num=input("Enter number: ")
ln = len(num)
for i in range(0, ln):
    print(num[ln-i-1])