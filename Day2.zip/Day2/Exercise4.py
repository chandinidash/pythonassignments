num=input("Enter number: ")
ln = len(num)
j = ln-1
k = int(ln/2)
i = 0
while True:
    if num[i] != num[j] or i>=j:
        break
    else:
        j -= 1
        i += 1
if i == k:
    print("Given number",num,"is a palindrome")
else:
    print("Given number",num,"is not a palindrome")